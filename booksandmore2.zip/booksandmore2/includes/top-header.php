<?php 
//session_start();

?>

<div class="top-bar animate-dropdown">
	<div class="container">
		<div class="header-top-inner">
			<div class="cnt-account">
				<ul class="list-unstyled">
                                       <li><a href="account/index.php"><i class="icon fa fa-user"></i>My Account</a></li>
					<li><a href="account/index.php"><i class="icon fa fa-user"></i>Sign Up</a></li>
					<li><a href="account/index.php"><i class="icon fa fa-sign-in"></i>Login</a></li>
				</ul>
			</div><!-- /.cnt-account -->

<div class="cnt-block">	
			</div>
			<div class="clearfix"></div>
		</div><!-- /.header-top-inner -->
	</div><!-- /.container -->
</div><!-- /.header-top -->