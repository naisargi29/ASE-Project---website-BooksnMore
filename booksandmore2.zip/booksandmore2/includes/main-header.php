
	<div class="main-header">
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-3 logo-holder">				
<div class="logo">
	<a href="index.php">
		<h2>Books and More</h2>
	</a>
</div>		
</div>
</div>

			